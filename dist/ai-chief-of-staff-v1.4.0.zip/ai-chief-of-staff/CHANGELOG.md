# Changelog

## v1.4.0

Fixes from a quality review. Most of them are hand-offs between behaviours that held while the leader was in the room and broke on a scheduled run.

- **`onboarding` no longer adopts a `CLAUDE.md` it did not write.** Step 0 never overwrites a file with content in it, so a folder that already had its own `CLAUDE.md` kept it, and every behaviour read that file as its rulebook with none of the thirteen gates in it. A `CLAUDE.md` now counts as the manual only if its first heading names the operating manual. Anything else stops setup and asks.
- **The workspace is always a folder named `ai-chief-of-staff`.** Every prompt in `SCHEDULES.md` names that folder, and onboarding scaffolded into whatever folder the session was in. Step 0 now finds or creates `ai-chief-of-staff/`, and `health-check` reports a workspace under any other name, or a foreign manual, as blocking.
- **An unapproved `tomorrow.md` no longer disappears.** `end-of-day-close` keeps its draft in the close file with a `status: awaiting approval` line. The next `morning-brief` reads that line, lists the draft under drafts waiting, and does not set the day from it.
- **Activation offers count their own renders.** "Drop it after three briefs" had nothing to count with. The offer line gains `shown: N`, the brief adds one per render, and the third unanswered render marks it `dropped`. The leader's answer can now be recorded from any later session, and so can a declined `health-check` finding.
- **The sweep's roll-up has a file.** It was "available to the morning brief" with no path, so on a scheduled run its decisions and `To verify` lines reached nobody. It now saves to `briefs/YYYY-MM-DD-sweep.md`, and the brief renders its urgent actions and every `To verify` line.
- **Nudge triggers look back a week.** `connection-check` runs on Monday, and "two or more meetings on yesterday's calendar" read a Sunday. Every gate 3 trigger now reads the seven days before the run, and the nudge names the day.
- **`decisions.md` agrees with itself about `Stood`.** Marking an entry `Stood` set a new review date that rule 4 forbade, so a held decision came back every Monday. Rule 4 now allows the new date and an appended `> Stood` line.
- **Worked examples corrected.** Marcus owes the hiring plan in every example, with one surname. The `health-check` example no longer cites briefs newer than the date it says the briefs stopped. The `decision-brief` example now says both filters lean to option 1 and the no-list decides it.
- **Counts brought up to date.** Fourteen behaviours, thirteen gates, six setup questions, six files you own. `README.md` lists `welcome`. `commitments.md` describes what `weekly-review` actually takes from it. `archive/README.md` lists the decisions archive. `onboarding` copies `QUICK-START.md`, which its templates already carried.
- **Zips are reproducible.** Every entry gets a fixed timestamp, so a rebuild with no source change leaves the fifteen zips untouched in git.

## v1.3.0

The product now speaks to the leader who runs it, not to a consultant installing it for somebody else.

- **Every guide is written in second person.** `READ-ME-FIRST.md`, `SCHEDULES.md`, and `README.md` said "the leader" 82 times between them and addressed whoever was doing the install. They now address the person the system is for. The consent passage changed most: it used to tell an installer to warn somebody before reading their mailbox, which makes no sense when the mailbox is your own. It now says what setup reads, that it does not store it, and what to do if you would rather it did not.
- **`DEPLOY-FOR-A-CLIENT.md` is no longer part of the product.** The consent script, the sixty-minute agenda, and the day 1/7/30 criteria were written for somebody deploying this on someone else's behalf. That is a delivery method, not a feature, and shipping it invited a reader to install a system for a person who never met it. It is out of the repo and out of the build.
- **New behaviour `welcome`, fourteenth.** The install card is a component inventory: skill names and a token cost. Nothing in a plugin can run at install time, so the guided introduction only ever happened when a human was in the room to start it. `welcome` says what the system does, what it needs, and what it will never do, then asks whether to set up and hands to `onboarding`. Under 300 words, writes nothing, never runs on a schedule.
- **The plugin and marketplace descriptions were rewritten.** They predated inbox triage and the decision log and spent every word on features. The card is the only prose a leader is guaranteed to read, so it now carries the trust line and says what to do next.
- **`check.py` gained two rules and lost one doc.** New: the folder tree in each platform's guide must match that platform's shipped workspace, both directions; and every filename `SCHEDULES.md` names must be one a behaviour writes, both directions. 486 checks to 541.

## v1.2.1

Documentation only. No behaviour, workspace file, or approval gate changed.

- **The folder home is now ranked rather than listed.** `READ-ME-FIRST.md` Path A step 2 gave three arrangements as peers and then named two of them "safest" in a closing sentence. It now gives three homes in order, each with the one thing it gives up: files saved to the Claude account give up the leader's own filesystem, a connector source gives up certainty about appends, and a local folder connected in Cowork gives up unattended runs. Every home fails something, and saying which is the decision the consultant is actually making.
- **One vocabulary per platform.** `DEPLOY-FOR-A-CLIENT.md` said "cloud storage the leader owns" on both platforms. On ChatGPT that is exactly right. On Claude it points at a connector source, which is the one home whose appends are not documented, so the runbook was steering Claude deployments toward the weakest option while `READ-ME-FIRST.md` steered them away. The phrase is now ChatGPT-only, and the Claude block names the three homes instead.
- **The two docs no longer contradict each other about laptops.** `DEPLOY-FOR-A-CLIENT.md` preferred "a folder connected in Cowork" while its own table, its troubleshooting section, and `SCHEDULES.md` all ruled a laptop out. A local folder is now a documented option 3 with a stated cost, and all four places say the same thing in the same words.
- **The append test is mandatory, whichever home you chose.** It was asked for only when Drive was the fallback, which is the case a consultant already distrusts. The home nobody thinks to doubt is the one that reads fine and silently writes nothing.
- **Path A distinguishes Cowork from Claude Code.** It read "Claude Code or Claude Cowork" as if a terminal and a desktop app were interchangeable for a non-technical leader. Cowork is the default and carries the connector toggles and the scheduled-tasks panel; Claude Code is for a leader who is technical and asks for it. `README.md` routes the same way.
- **The ChatGPT folder map matched no ChatGPT deployment.** "What is in the folder" listed `CLAUDE.md`, `skills/`, and `example/`. A ChatGPT workspace ships `PROJECT-INSTRUCTIONS.md`, has no `skills/` because the behaviours are the prompts you paste, and keeps `example/` beside the workspace rather than inside it. The tree is now split per platform and each one lists what that platform actually ships.
- **Two more hardcoded manual names now resolve per platform.** The "if you only change one thing" line and the `SCHEDULES.md` note on naming the manual both said `CLAUDE.md` in the ChatGPT render, where the manual is `PROJECT-INSTRUCTIONS.md`. Split docs exist so a reader never meets the other platform's paths, and these were the last two that leaked.

## v1.2.0

- The install guide, the schedule prompts, and the client runbook now render once per platform, into `docs/claude/` and `docs/chatgpt/`. A consultant deploys to one platform and reads only the paths that apply to it. A Claude deployment reads 836 lines where the combined set was 1,099, and a ChatGPT deployment 864. `SCHEDULES.md` alone goes from 557 lines to 345 and 376.
- Filenames are identical in both directories, so every cross-link between docs resolves inside whichever set the reader opened and no link has to know its own platform.
- `README.md` is the router. It names the two sets and says to read only one.
- Every cross-platform path reference removed. A Claude reader is no longer sent to a Path C their guide does not contain, and a ChatGPT reader no longer reads three bullets about what Path A leaves out.
- `QUICK-START.md`, `CHANGELOG.md`, and `CREDITS.md` stay single at the repo root. The leader's page reads the same on both platforms, and splitting it would double a file to vary one sentence.
- `build.py` gains `PLATFORM_DOCS`. Anything named there renders once per platform into `docs/`; everything else renders once to the root.
- `check.py` gains three rules, 465 checks to 486: both renders of a split doc exist and reach the release zip, the two renders differ (a doc that splits identically is duplicated rather than split), and no stale root copy survives beside `docs/`.

## v1.1.0

- Five new behaviours: `inbox-triage`, `chase`, `decision-brief`, `recall`, `health-check`. Thirteen in total.
- New workspace file `decisions.md`: closed calls, the reasoning, the conditions that would reopen each one, and a Monday review pass over the ones that have come due.
- Three new approval gates, thirteen in total. No outcome written to `decisions.md` that the leader has not stated in the same session, no state changed in a connected source, and `tomorrow.md` never saved without approval.
- New `example/` folder: a filled-in workspace for an invented leader, plus one brief, one person file, and one meeting note. Reference only. No behaviour reads it.
- New `QUICK-START.md` for the leader, `DEPLOY-FOR-A-CLIENT.md` for whoever installs it, and `SCHEDULES.md` with every recurring prompt in full.
- `READ-ME-FIRST.md` corrected against current platform documentation: plugin install differs between Claude Code and Claude Cowork and does not run in ordinary Claude chat, skill uploads need **Code execution and file creation** on first and live under **Customize > Skills**, ChatGPT can write files through a connected app, ChatGPT caps active scheduled tasks per plan and cannot run one more often than hourly, and a cloud scheduled run reaches connected sources rather than a hard drive.
- `READ-ME-FIRST.md` now points at `SCHEDULES.md` for prompt text rather than restating it.
- The eight original behaviours updated to carry their half of the new contracts. `onboarding` creates `decisions.md` and hands off to `health-check`. `weekly-review` renders the Monday decisions pass and leaves the chase drafts to `chase`. `morning-brief` renders what the morning triage pass appended and drafted, and reads it once. `end-of-day-close` runs a triage pass when none has run since morning.
- Every file in `briefs/` now carries a suffix, including the morning brief (`YYYY-MM-DD-brief.md`), so two jobs on one day never collide and a behaviour reading another's output can find it by name.
- `chase` runs two or three days after `weekly-review` rather than the same morning, and reads that week's review so a release is proposed once.
- Build copies `src/example/` into the workspace and `decisions.md` into the workspace templates. `check.py` now fails when `onboarding` step 0 does not name every file in `src/workspace/`.

## v1.0.0

First public release.

- Eight behaviours: `onboarding`, `morning-brief`, `meeting-prep`, `transcript-to-actions`, `daily-transcript-sweep`, `end-of-day-close`, `weekly-review`, `connection-check`.
- Six workspace files and four output folders, created automatically by `onboarding` when they do not exist.
- Capability registry (`connections.md`) tracking Calendar, Email, Documents, Transcripts, Chat, Tasks, and CRM by job rather than by vendor.
- Three-gate nudge policy, one capability line per brief maximum, permanent silencing on request.
- Ten approval gates. The system drafts and never sends.
- Single-source build producing the Claude plugin, the Claude drop-in folder, per-behaviour upload ZIPs, and the ChatGPT project pack.
