---
name: end-of-day-close
description: "Close the day: what moved, what came in, ledger changes, and a drafted tomorrow.md for approval. 200 words. Use at end of day or when the leader says they are done."
---

# end-of-day-close

## Trigger

- End of the working day, on a schedule, timed against the hard stop in `about-me.md`.
- On demand: "close out the day", "I'm done", "what's tomorrow look like".

## Why this behaviour matters more than it looks

This is the one that produces `tomorrow.md`, and `tomorrow.md` is the cleanest signal the whole system has, because the leader wrote it. Every morning brief starts from it. If this behaviour produces a lazy draft, tomorrow's brief starts from a lazy premise.

Spend the effort here. The leader spends thirty seconds approving it and gets a better morning.

## Reading order

1. `CLAUDE.md`.
2. `connections.md`.
3. This morning's brief in `briefs/`, so you can compare intent against outcome.
4. `commitments.md`.
5. `my-work.md`, sections 2 and 5.
6. `about-me.md`, section 2 (working rhythm), section 7 (always protect).
7. Today's calendar as it actually ran. Today's mail. Any transcripts from today.
8. Tomorrow's calendar.

If no `inbox-triage` pass has run since this morning, run one before step 7. Today's new commitments come from that pass, and slot 2 is counting what it appended. Skip it when the afternoon pass has already run, because the ledger is current and reading the mail twice produces the same entries twice.

---

## Structure

200 words for the report. `tomorrow.md` is a separate artifact and has its own 150-word cap.

### 1. What moved

Against this morning's priorities. Say plainly which ones progressed and which did not. Do not soften it and do not editorialise about it.

If a priority did not move for a third day running, say that. Three days is a pattern and the leader should decide about it rather than drift.

### 2. What came in

New commitments captured today, from mail, meetings, or chat. Count and the notable ones.

New things that landed on the calendar for the next few days that the leader may not have noticed.

### 3. Ledger changes

What you appended, what you propose closing, what needs verifying. Anything you closed needs its evidence named.

### 4. Proposed tomorrow.md

Draft the file, using its own structure: must respect, carry forward, calendar constraints, protect, avoid, and one question for the leader.

Rules for the draft:

- **Must respect** gets two or three items. Not five. If everything must happen, nothing must.
- **Carry forward** is not everything that slipped. Only what still earns the time tomorrow. Something that has slipped three days and is not on the priority list should be proposed for release, not carried again.
- **Calendar constraints** come from tomorrow's actual calendar, plus the protected blocks in `about-me.md` section 7.
- **Avoid** comes from `my-work.md` section 5, filtered to whatever is actually likely to pull tomorrow.
- **Question for the leader** is the one thing you genuinely could not decide. If there is nothing, leave it out. Do not manufacture a question to fill the slot.

Show the draft. Ask for approval. Save only on a yes.

The draft also goes into the close file, under its own heading, with a status line beneath it:

```
status: awaiting approval
```

This job usually runs on a schedule, and the leader may not answer until morning, or at all. The status line is how the next `morning-brief` knows a draft is sitting there unapproved. When the leader says yes, in this session or any later one, save `tomorrow.md` and change the line to `status: approved YYYY-MM-DD`. When they say no, change it to `status: declined`.

---

## Rules

- Do not congratulate. "Good work today" is filler and it costs words the leader needs.
- Do not report on things that did not need the leader.
- Do not mark a commitment closed because it looks finished. Evidence or nothing.
- If the day went badly, say so in one clause and move to tomorrow. The leader knows. Dwelling helps nobody.
- Do not raise capability gaps here. That is the morning brief's one slot.

## Approval rules

- May append and update `commitments.md` with sourced entries.
- May save today's close to `briefs/YYYY-MM-DD-close.md`, with the proposed `tomorrow.md` and its status line inside it.
- May **not** save `tomorrow.md` without explicit approval. This one is non-negotiable, because the morning brief treats that file as the leader's own words. If it is saved unapproved, the whole source hierarchy is built on a guess.
- May not send anything.

## Worked example

```
WHAT MOVED
Ridley proposal went out at 15:40. Marcus 1:1 happened. He committed to the
hiring plan by Jul 25. Quarterly planning doc did not move. Third day.

WHAT CAME IN
2 new commitments (budget draft for Elena, board pre-read for Elena).
Board sync added next Tuesday 09:00, which lands on your deep work block.

LEDGER
Appended 2. Re-dated 1 (Marcus hiring plan, due Jul 25, from the 1:1).
Closed 1 (Ridley proposal, evidence: sent mail 15:40). 1 to verify from the
ops call.

PROPOSED tomorrow.md
  Must respect
    1. Answer Sven on the redline. Due tomorrow.
    2. Decide whether quarterly planning stays a priority or gets released.
  Carry forward
    Priya timeline (due Jul 27, not urgent tomorrow)
  Calendar
    09:00 deep work. 14:00 Sven.
  Protect
    09:00-11:00 block. Tuesday's board sync conflicts with it, flagged separately.
  Avoid
    Website redesign thread. my-work.md says not this quarter.
  Question
    Tuesday's board sync sits on your deep work block. Move it, or move the block?
  status: awaiting approval

Save this?
```
